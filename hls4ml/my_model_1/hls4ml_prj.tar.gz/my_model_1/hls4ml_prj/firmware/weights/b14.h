//Numpy array shape [1]
//Min 0.048312839121
//Max 0.048312839121
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
model_default_t b14[1];
#else
model_default_t b14[1] = {0.0483128391};
#endif

#endif
