//Numpy array shape [1]
//Min 0.106985151768
//Max 0.106985151768
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[1];
#else
model_default_t b11[1] = {0.1069851518};
#endif

#endif
